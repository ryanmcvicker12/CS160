package project02_lab2_mcvirm01;

import java.util.*;
import java.text.*;




public class LandCalculation{


	static final int CONVERSION = 43560 ;

	public static void main(String[] args){

		int area = 534521;
		
		double acres = area / CONVERSION;	

		System.out.printf("The area of the land in square feet is: %d square feet\n", area);

		System.out.printf("The area of the land in acres is: %f\n", acres );

		DecimalFormat df = new DecimalFormat("# #.000");

		System.out.println("The area of the land in acres is: " + df.format(acres));
		
		DecimalFormat df2 = new DecimalFormat("# #.#####");
		
		System.out.println("The area of the land in acres is: " + df2.format(acres));
	}
}
