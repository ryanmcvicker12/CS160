package project02_lab2_mcvirm01;

import java.util.*;



/* Ryan McVicker

* 01-25-2021


**
	***
	*****
	   ***
              **
*/


public class PatternPrint{

	//deleting the 'void' keyword raised an error stating the function needs a return type	
	// changing keyword 'main' to 'starting' raised an error stating there must be a main function or entry point
	//changing the name 'args' to something caused no errors
	public static void main(String[] args){

		String patternString = "**\n" + "\t***\n"+ "\t*****\n" + "\t   ***\n"+ "\t      **\n";
		//changing the parentheses to curly brackets caused an error stating that this line is not a statement
		System.out.println(patternString);
		//changing the type 'int' to 'Integer' caused no errors. 
		int favoriteNumber = 19;
		//Changing the semi colon to a colon raised an error stating there needed to be an end to the statment
		System.out.printf("This program was created by Ryan McVicker. My favorite number is %d.\n", favoriteNumber);
	} 
}
